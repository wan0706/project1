// document.addEventListener('DOMContentLoaded', function() {
//     var loggedInUserEmail = document.getElementById('loggedInUserInfo').getAttribute('data-email');
//     var inquiryWriterEmail = document.getElementById('writerInfo').getAttribute('data-email');
//
//     var deleteForm = document.getElementById('deleteForm');
//     var editLink = document.getElementById('editLink');
//
//     // 현재 사용자와 글 작성자의 이메일이 일치하지 않으면 버튼을 숨깁니다.
//     if (loggedInUserEmail !== inquiryWriterEmail) {
//         deleteForm.style.display = 'none';
//         editLink.style.display = 'none';
//     }
// });