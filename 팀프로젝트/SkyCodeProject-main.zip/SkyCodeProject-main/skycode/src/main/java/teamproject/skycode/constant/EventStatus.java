package teamproject.skycode.constant;

public enum EventStatus {
    ONGOING, END, WINNER
}
