package teamproject.skycode.constant;

public enum TicketStatus {
    SELL, SOLD_OUT
    // 판매 상태
}
