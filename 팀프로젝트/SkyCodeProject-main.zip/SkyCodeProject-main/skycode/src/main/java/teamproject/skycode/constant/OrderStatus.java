package teamproject.skycode.constant;

public enum OrderStatus {
    ONGOING, BUY
    // 구매 상태
}
